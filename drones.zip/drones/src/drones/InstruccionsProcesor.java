package drones;

import drones.dto.Coordinates;

public interface InstruccionsProcesor {

	Coordinates processInstruction(Coordinates coordinates, String instruction);
}
