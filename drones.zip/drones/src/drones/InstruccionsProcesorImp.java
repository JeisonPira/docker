package drones;

import drones.dto.Coordinates;
import drones.movements.DroneMovements;
import drones.movements.Movements;

public class InstruccionsProcesorImp implements InstruccionsProcesor {

	public Movements movements = new DroneMovements();

	@Override
	public Coordinates processInstruction(Coordinates coordinates, String instruction) {
		if ("A".equals(instruction)) {
			coordinates = movements.moveForward(coordinates);
		} else if ("I".equals(instruction)) {
			coordinates = movements.turnLeft(coordinates);
		} else if ("D".equals(instruction)) {
			coordinates = movements.turnRight(coordinates);
		}
		
		return coordinates;	
	}

}
