package drones;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import drones.dto.Coordinates;

public class Main {

	public static void main(String[] args) {

		String pathFile = String
				.valueOf(JOptionPane.showInputDialog("Por favor ingrese la ruta del archivo de pedidos."));

		try {

			OrdersManager ordersManager = new OrdersManager();
			List<String> orders = ordersManager.processFile(pathFile);
			List<Coordinates> result = new ArrayList<>();
			Coordinates coordinates = new Coordinates(0, 0, "N");

			for (String order : orders) {
				coordinates = ordersManager.deliveryOrders(coordinates, order);
				System.out.println(coordinates.toString());
				result.add(coordinates);
			}

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
