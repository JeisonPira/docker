package drones;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;	
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import drones.exceptions.FileError;

public class File {

	public List<String> readFile(String path) throws IOException, FileError {
		
		String fileSeparator = System.getProperty("file.separator");
		
		String[] splitPath = path.split("\\" + fileSeparator);
		
		if(invalidNameFile(splitPath[splitPath.length - 1	])) {
			throw new FileError("El nombre del archivo es incorrecto.");
		}
		
		String chain;
		List<String> orders = new ArrayList<>();
		FileReader fileReader = new FileReader(path);
		BufferedReader bufferedReader = new BufferedReader(fileReader);	
		while ((chain = bufferedReader.readLine()) != null) {
			if(validChain(chain)) {
				throw new FileError("El archivo contiene caracteres invalidos.");
			}
			orders.add(chain);
		}
		bufferedReader.close();
		return orders;
	}

	private boolean validChain(String chain) {
		
		Pattern pattern = Pattern.compile("[^ADI]");
		Matcher matcher = pattern.matcher(chain);
		return matcher.find();	
	}	

	private boolean invalidNameFile(String nameFile) {
		if("in.txt".equals(nameFile)) {
			return false;
		}
		return true;
	}
	
}
