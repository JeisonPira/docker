package drones.movements;

import drones.dto.Coordinates;

public class DroneMovements implements Movements {

	@Override
	public Coordinates moveForward(Coordinates coordinates) {
		if ("N".equals(coordinates.getOrientation())) {
			coordinates.setY(coordinates.getY() + 1);
		} else if ("S".equals(coordinates.getOrientation())) {
			coordinates.setY(coordinates.getY() - 1);
		} else if ("E".equals(coordinates.getOrientation())) {
			coordinates.setX(coordinates.getX() + 1);
		} else if ("W".equals(coordinates.getOrientation())) {
			coordinates.setX(coordinates.getX() - 1);
		}

		return coordinates;
	}

	@Override
	public Coordinates turnLeft(Coordinates coordinates) {
		String orientation = "";
		Coordinates currentCoordenates = new Coordinates();
		if ("N".equals(coordinates.getOrientation())) {
			orientation = "W";
		} else if ("W".equals(coordinates.getOrientation())) {
			orientation = "S";
		} else if ("S".equals(coordinates.getOrientation())) {
			orientation = "E";
		} else if ("E".equals(coordinates.getOrientation())) {
			orientation = "S";
		}

		currentCoordenates.setX(coordinates.getX());
		currentCoordenates.setY(coordinates.getY());
		currentCoordenates.setOrientation(orientation);
		return currentCoordenates;
	}

	@Override
	public Coordinates turnRight(Coordinates coordinates) {
		String orientation = "";
		Coordinates currentCoordenates = new Coordinates();
		if ("N".equals(coordinates.getOrientation())) {
			orientation = "E";
		} else if ("E".equals(coordinates.getOrientation())) {
			orientation = "S";
		} else if ("S".equals(coordinates.getOrientation())) {
			orientation = "W";
		} else if ("W".equals(coordinates.getOrientation())) {
			orientation = "N";
		}

		currentCoordenates.setX(coordinates.getX());
		currentCoordenates.setY(coordinates.getY());
		currentCoordenates.setOrientation(orientation);
		return currentCoordenates;
	}

}
