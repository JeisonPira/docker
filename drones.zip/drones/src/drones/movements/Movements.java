package drones.movements;

import drones.dto.Coordinates;

public interface Movements {

	Coordinates moveForward(Coordinates coordinates);

	Coordinates turnLeft(Coordinates coordinates);

	Coordinates turnRight(Coordinates coordinates);

}
