package drones.dto;

public class Coordinates {

	public int x = 0;
	public int y = 0;
	public String orientation = "N";

	public Coordinates() {
	}

	public Coordinates(int x, int y, String orientation) {
		super();
		this.x = x;
		this.y = y;
		this.orientation = orientation;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public String getOrientation() {
		return orientation;
	}

	public void setOrientation(String orientation) {
		this.orientation = orientation;
	}

	@Override
	public String toString() {
		return "Coordinates [x=" + x + ", y=" + y + ", orientation=" + orientation + "]";
	}

}
