package drones;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import drones.dto.Coordinates;
import drones.exceptions.FileError;

public class OrdersManager {

	public File file = new File();
	public InstruccionsProcesor instruccionsProcesor = new InstruccionsProcesorImp();

	public List<String> processFile(String path) throws IOException, FileError {
		List<String> orders = file.readFile(path);
		if (orders.size() > 3) {
			throw new FileError("El archivo contiene mas de 3 ordenes.");
		}
		return orders;
	}

	public Coordinates deliveryOrders(Coordinates coordinates, String order) {
		List<String> characters = Arrays.asList(order.split(""));
		for (String character : characters) {
			coordinates = instruccionsProcesor.processInstruction(coordinates, character);
		}
		return coordinates;
	}

	public boolean processResult(List<Coordinates> result) throws IOException {

		return true;
	}

	private String getDirection(String orientation) {
		switch (orientation) {
		case "S":
			return "direcci�n Sur";
		case "N":
			return "direcci�n Norte";
		case "W":
			return "direcci�n Occidente";
		case "E":
			return "direcci�n Oriente";
		default:
			break;
		}
		return "";
	}
}
