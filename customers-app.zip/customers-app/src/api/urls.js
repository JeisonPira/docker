const urlBase = "http://localhost:3001";

export const urlCustomers = `${urlBase}/customers`;
