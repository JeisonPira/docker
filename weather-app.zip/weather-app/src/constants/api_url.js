export const api_key = "46cadc0fb17d1040ba9a1e21d87a0bd0";
export const end_point = "https://api.openweathermap.org/data/2.5";
